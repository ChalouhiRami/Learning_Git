from datetime import datetime

def print_error(suffix,prefix):
    print(f"{datetime.now()} - {prefix} ##### {suffix}")